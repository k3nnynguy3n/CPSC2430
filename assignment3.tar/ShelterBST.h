#include <string> 
#ifndef SHELTERBST_H
#define SHELTERBST_H 
using namespace std; 

class ShelterBST {
    
    private:
    //Pet struct with the constructor for the pet 
    struct Pet {
        string name; 
        int age;
        Pet(string name, int age) {
            this->name = name;
            this->age = age; 
        }
    };

    //Tree node struct with tree node constructor for the node of each pet in the tree 
    struct TreeNode {
        Pet* pet; // you must use a Pet pointer
        TreeNode* left;
        TreeNode* right;
        TreeNode(Pet* pet) {
            this->pet = pet;
            left = nullptr; 
            right = nullptr; 
        }
    };

    //Private methods
    TreeNode* root;
    TreeNode* insert(TreeNode* root, Pet* pet);
    TreeNode* search(TreeNode* root, string name);
    TreeNode* findparent(TreeNode* root, string name); 
    TreeNode* findpredecessor(TreeNode* root, string name); 
    TreeNode* destroy(TreeNode* root); 
    TreeNode* deletenode(TreeNode* root, string name);
    void inorder(TreeNode* root);
    void preorder(TreeNode* root);
    void postorder(TreeNode* root);
    int count(TreeNode* root); 
    int getheight(TreeNode* root); 
    int findinternal(TreeNode* root);
    int getwidth(TreeNode* root, int num); 
    bool checkbalance(TreeNode* root); 


    public:
    //Public methods
    ShelterBST();
    int width(int num);
    void insertPet(string name, int age);
    void searchPet(string name);
    void parent(string name);
    void predecessor(string name); 
    void destroyTree();
    void inorderDisplay();
    void preorderDisplay();
    void postorderDisplay();
    void countTreeNodes();
    void treeHeight(); 
    void internal(); 
    void balance(); 
    void deleten();

};

#endif //ShelterBST_h
