#include "ShelterBST.h"
#include <iostream> 
#include <string> 
using namespace std;

//Private Methods: 
ShelterBST::TreeNode* ShelterBST::insert(TreeNode* root, Pet* pet) {

    //if the tree is empty creates new tree node for the pet
    if (root == nullptr) {
        return new TreeNode(pet); 
    //Checks for dulpicate
    } else if (pet->name == root->pet->name) {
        return root; 
    } else if (pet->name > root->pet->name) {
        root->right = insert(root->right, pet);
    } else {
        root->left = insert(root->left, pet); 
    } 
    return root; 
}

//Checks if the left and right subtree of the passed in animal by age 
ShelterBST::TreeNode* ShelterBST::search(TreeNode *root, string name) {

    //Checks if the tree is empty or if the pet is the root
    if (root == nullptr || root->pet->name == name) {
        return root; 
    }

    if (name < root->pet->name) {
        return search(root->left, name); 
    } else {
        return search(root->right, name); 
    }
}

ShelterBST::TreeNode* ShelterBST::findparent(TreeNode* root, string name) {

    if (root == nullptr) {
        return root; 
    //Checks if the root to the left or the right is not nullptr and is equal to the name 
    } else if ((root->left != nullptr && root->left->pet->name == name) || 
              (root->right != nullptr && root->right->pet->name == name)) {
        return root; 
    } else {
        if (root->pet->name > name) {
            return findparent(root->left, name);
        } else {
            return findparent(root->right, name); 
        }
    }
}

ShelterBST::TreeNode* ShelterBST::findpredecessor(TreeNode* root, string name) {

    if (root == nullptr) {
        return root;
    }

    //Checks if the node being search for is even in the tree
    TreeNode* find = search(root, name); 
    if (find == nullptr) {
        return find; 
    }

    //If the node has a left child finxd the max value in the left subtree
    if (find->left != nullptr) {
        find = find->left; 
        while (find->right != nullptr) {
            find = find->right; 
        }
        return find; 
    }
    
    //Otherwise, find the predecessor of the node by traversing up until it finds a node whos name is smaller than the name given
    TreeNode* pre = nullptr; 
    TreeNode* ancestor = root; 

    while (ancestor != pre) {
        if (find->pet->name > ancestor->pet->name) {
            pre = ancestor; 
            ancestor = ancestor->right; 
        } else {
            ancestor = ancestor->right; 
        }
    }
    return pre; 
}


//Deltes a node and replaces the deleted node with its predecessor
ShelterBST::TreeNode* ShelterBST::deletenode(TreeNode* root, string name) {
    
    if (root == nullptr) {
        return root;
    }
    
    //Search left and right tree for the node that is going to be deleted 
    if (name < root->pet->name) {
        root->left = deletenode(root->left, name);
    } else if (name > root->pet->name) {
        root->right = deletenode(root->right, name);
    } else {
        //If the node matches the name inputted 
        //Delete if node has no children
        if (root->left == nullptr && root->right == nullptr) {
            delete root;
            root = nullptr;
        }
        //Replace it with right child, if the deleted node only has one right child 
        else if (root->left == nullptr) {
            TreeNode* temp = root;
            root = root->right;
            delete temp;
        }
        //Replace it with the left child, if the deleted node only has one left child 
        else if (root->right == nullptr) {
            TreeNode* temp = root;
            root = root->left;
            delete temp;
        }
        //If the node has two children, find its inorder predecessor
        else {
            TreeNode* temp = findpredecessor(root->left, name);
            root->pet = temp->pet;
            root->left = deletenode(root->left, temp->pet->name);
        }
    }
    return root;
}

//Destroys and deletes every node in the binary tree 
ShelterBST::TreeNode* ShelterBST::destroy(TreeNode* root) {

    if (root == nullptr) {
        return root; 
    } 
    destroy(root->left);
    destroy(root->right); 
    delete root; 
    
    return root; 
}


//Prints the nodes in the tree from left, middle (root), right
void ShelterBST::inorder(TreeNode * root) {
    
    if (root == nullptr) {
        return;
    
    } else {
        inorder(root->left); 
        cout << root->pet->name << ", " << root->pet->age << endl; 
        inorder(root->right); 
    }
}

//Prints the nodes in the tree from middle (root), left, right
void ShelterBST::preorder(TreeNode * root) {

    if (root == nullptr) {
        return;
    
    } else {
        cout << root->pet->name << ", " << root->pet->age << endl; 
        preorder(root->left); 
        preorder(root->right); 
    }
}

//Prints the nodes in the tree from left, right, middle (root)
void ShelterBST::postorder(TreeNode * root) {
    
    if (root == nullptr) {
        return;
    
    } else {
        postorder(root->left); 
        postorder(root->right); 
        cout << root->pet->name << ", " << root->pet->age << endl; 
    }
}

//Counts the roots in the tree 
int ShelterBST::count(TreeNode * root) {

    if (root == nullptr) {
        return 0; 
    } else {
        return 1 + count(root->left) + count(root->right); 
    }
}

//Gets the height of the tree 
int ShelterBST::getheight(TreeNode * root) {
    
    int leftHeight, rightHeight;

    if (root == nullptr) {
        return -1; 
    } else {
        leftHeight = getheight(root->left);
        rightHeight = getheight(root->right); 
    }
    return max(leftHeight, rightHeight) + 1; 
}

//Finds the internal amount of nodes in the binary search tree
int ShelterBST::findinternal(TreeNode* root) {
    
    //Checks if a node is nullptr or if it is a leaf node 
    if (root == nullptr || (root->left == nullptr && root->right == nullptr)) {
        return 0; 
    } else {
        return 1 + findinternal(root->left) + findinternal(root->right);
    } 
 }

//Checks if the tree is balanced between the subtrees 
bool ShelterBST::checkbalance(TreeNode* root) {

    if (root == nullptr) {
        return true;
    } 
    //Gets the height of the left and right subtree
    int leftheight = getheight(root->left); 
    int rightheight = getheight(root->right); 
    //Finds the differences and if it is above 1 then it is not balanced 
    if (abs(leftheight - rightheight) > 1) {
        return false; 
    }
    return checkbalance(root->left) && checkbalance(root->right); 
}

//Gets the width of the tree at the inputted level
int ShelterBST::getwidth(TreeNode* root, int num) {

    if (root == nullptr) {
        return 0; 
    } else if (num == 1) {
        return 1; 
    } else {
        return getwidth(root->left, num - 1) + getwidth(root->right, num-1);
    }
}



//Public Methods: 
ShelterBST::ShelterBST() {
    
    root = nullptr;
}

//Inserts pet by calling the insert function   
void ShelterBST::insertPet(string name, int age) {
    
    root = insert(root, new Pet(name, age));
}
        
//Searches the for the pet by name, and then prints letting the user know if the pet has been foun or not
void ShelterBST::searchPet(string name) {
    
    TreeNode* result = search(root, name);
    if (result) {
        cout << result->pet->name << " was found!" << endl; 
    } else {
        cout << "Pet was not found, sorry" << endl; 
    }
}

//Prints the inorder display of the pets by calling the inorder function
void ShelterBST::inorderDisplay() {
    
    cout << "In-Order:" << endl; 
    inorder(root);
    cout << endl;
}
        
//Prints the preorder display of the pets by calling the preorder function 
void ShelterBST::preorderDisplay() {
    
    cout << "Pre-Order:" << endl; 
    preorder(root);
    cout << endl;
}

//Prints the postorder display of the pets by calling the postorder function 
void ShelterBST::postorderDisplay() {
    
    cout << "Post-Order:" << endl; 
    postorder(root);
    cout << endl; 
}

//Prints the amount of nodes/roots that in the tree 
void ShelterBST::countTreeNodes() {
    
    int nodecount = count(root); 
    cout << "There are " << nodecount << " nodes in the Shelter" << endl; 
}

//Prints the height of the tree
void ShelterBST::treeHeight() {

    int height = getheight(root);
    cout << "The height of the tree is: " << height << endl; 
}

//Find the parent of the node passed in and returns the parent
void ShelterBST::parent(string name) {

    TreeNode* printparent = findparent(root, name); 
    if (printparent != nullptr) {
        cout << "The parent is: " << printparent->pet->name << endl; 
    } else {
        cout << "No parent was found" << endl; 
    }
}

//Destroys and deallocates the entire binary search tree
void ShelterBST::destroyTree() {

    destroy(root);
    cout << "The binary tree has been destroyed" << endl << endl; 
}

//Returns the predecessor of the inputted tree 
void ShelterBST::predecessor(string name) {

    TreeNode* pre = findpredecessor(root, name); 

    if (pre == nullptr) {
        cout << "No Predecessor found for " << name << endl; 
    } else {
        cout << "The predecessor is: " << endl;
        cout << "Name: " << root->pet->name << endl;
        cout << "Age: " << root->pet->age << endl; 
    }
}


//Prints out the number of internal nodes that are in the tree
void ShelterBST::internal() {

    int internalnodes = findinternal(root); 
    cout << "There are " << internalnodes << " internal nodes in this binary search tree" << endl; 
}

//Prints the amount of nodes at a given inout representing at which level of the tree
int ShelterBST::width(int num) {

    return getwidth(root, num);
}

void ShelterBST::balance() {

    bool tandf = checkbalance(root); 
    cout << "The tree is "; 
    
    if (tandf) {
        cout << "balanced" << endl; 
    } else {
        cout << "not balanced" << endl; 
    }
}

void ShelterBST::deleten() {
    
    string animalname;
    cout << "Enter a name to delete: ";
    cin >> animalname; 
    root = deletenode(root, animalname);
    if (root == nullptr) {
        cout << "Sorry that name was not found" << endl << endl; 
    } else {
        cout << "Congrats, you removed " << root->pet->name << ", age " << root->pet->age << endl << endl; 
    }
}